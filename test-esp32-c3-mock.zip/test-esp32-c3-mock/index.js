console.log("Loaded ESP32-C3 Mock Board Support v1.0.0");
module.exports = {
    board: "board.json"
};
